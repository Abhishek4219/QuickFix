import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function QuickFixHome() {
  const [isPremium, setIsPremium] = useState(false);
  const [booking, setBooking] = useState({ name: '', phone: '', address: '', service: '', time: '', notes: '' });
  const [provider, setProvider] = useState({ name: '', phone: '', type: '', city: '' });

  const handleBookingSubmit = () => {
    const whatsappURL = `https://wa.me/91${booking.phone}?text=QuickFix Booking%20Request%20\nName:%20${booking.name}%20\nAddress:%20${booking.address}%20\nService:%20${booking.service}%20\nTime:%20${booking.time}%20\nNotes:%20${booking.notes}`;
    window.open(whatsappURL, '_blank');
  };

  const handleProviderSubmit = () => {
    const whatsappURL = `https://wa.me/917571950373?text=New Provider%20Signup%20\nName:%20${provider.name}%20\nPhone:%20${provider.phone}%20\nService:%20${provider.type}%20\nCity:%20${provider.city}`;
    window.open(whatsappURL, '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-blue-700 mb-2">QuickFix - Instant Local Services</h1>
        <p className="text-gray-600 text-lg">Get electricians, plumbers, tutors & more at your doorstep fast.</p>
      </header>

      {!isPremium && (
        <Card className="max-w-xl mx-auto mb-10">
          <CardContent className="p-6 text-center">
            <h2 className="text-2xl font-semibold text-green-600 mb-2">Upgrade to Premium ₹99/month</h2>
            <p className="text-gray-600 mb-4">Get priority bookings, verified professionals & exclusive discounts.</p>
            <div className="flex justify-center mb-4">
              <Image src="/quickfix_upi_qr.png" alt="QuickFix UPI QR" width={200} height={200} />
            </div>
            <p className="text-sm text-gray-500">UPI ID: <strong>7571950373@upi</strong></p>
            <p className="text-xs text-gray-400 mt-1 mb-4">Send ₹99 & enter reference ID below</p>
            <Input placeholder="Enter payment reference ID" className="mb-2" />
            <Button onClick={() => setIsPremium(true)} className="w-full bg-green-600 hover:bg-green-700">Confirm & Unlock Premium</Button>
          </CardContent>
        </Card>
      )}

      {isPremium && (
        <div className="text-center text-green-700 font-semibold text-xl">✅ Premium Activated! Enjoy priority support & faster bookings.</div>
      )}

      <section className="mt-10 max-w-4xl mx-auto">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Available Services</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {["Electrician", "Plumber", "Carpenter", "Home Tutor", "AC Repair", "Salon at Home"].map((service) => (
            <Card key={service} className="p-4 hover:shadow-xl cursor-pointer">
              <CardContent className="text-center text-blue-700 font-semibold">{service}</CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="mt-14 max-w-2xl mx-auto">
        <h3 className="text-xl font-bold text-gray-800 mb-4">📋 Book a Service</h3>
        <Input placeholder="Your Name" className="mb-2" value={booking.name} onChange={(e) => setBooking({ ...booking, name: e.target.value })} />
        <Input placeholder="Phone Number" className="mb-2" value={booking.phone} onChange={(e) => setBooking({ ...booking, phone: e.target.value })} />
        <Input placeholder="Full Address" className="mb-2" value={booking.address} onChange={(e) => setBooking({ ...booking, address: e.target.value })} />
        <Input placeholder="Service Required (e.g. Plumber)" className="mb-2" value={booking.service} onChange={(e) => setBooking({ ...booking, service: e.target.value })} />
        <Input placeholder="Preferred Time (e.g. 4 PM today)" className="mb-2" value={booking.time} onChange={(e) => setBooking({ ...booking, time: e.target.value })} />
        <Textarea placeholder="Additional Notes (optional)" className="mb-2" value={booking.notes} onChange={(e) => setBooking({ ...booking, notes: e.target.value })} />
        <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={handleBookingSubmit}>Submit Booking via WhatsApp</Button>
      </section>

      <section className="mt-14 max-w-2xl mx-auto">
        <h3 className="text-xl font-bold text-gray-800 mb-4">🧑‍🔧 Provider Registration</h3>
        <Input placeholder="Your Name" className="mb-2" value={provider.name} onChange={(e) => setProvider({ ...provider, name: e.target.value })} />
        <Input placeholder="Phone Number" className="mb-2" value={provider.phone} onChange={(e) => setProvider({ ...provider, phone: e.target.value })} />
        <Input placeholder="Service Type (e.g. Electrician)" className="mb-2" value={provider.type} onChange={(e) => setProvider({ ...provider, type: e.target.value })} />
        <Input placeholder="City / Area" className="mb-2" value={provider.city} onChange={(e) => setProvider({ ...provider, city: e.target.value })} />
        <Button className="w-full bg-orange-600 hover:bg-orange-700" onClick={handleProviderSubmit}>Send Details via WhatsApp</Button>
      </section>
    </div>
  );
}
